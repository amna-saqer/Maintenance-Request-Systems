<?php
session_start();
require 'dbconfig.in.php';


if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'manager') {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $ticketId = $_POST['ticket_id'] ?? null;
    $staffId  = $_POST['staff_id'] ?? null;

    if ($ticketId && $staffId) {

    
        $stmt = $pdo->prepare(
            "UPDATE tickets
             SET status = 'In Progress',
                 assigned_staff_id = :staff_id,
                 assigned_staff = (SELECT name FROM users WHERE id = :staff_id),
                 assigned_date = NOW()
             WHERE id = :ticket_id"
        );

        $stmt->execute([
            'staff_id'   => $staffId,
            'ticket_id'  => $ticketId
        ]);
    }

    header("Location: view.php?id=" . urlencode($ticketId));
    exit;
}




$id = $_GET['id'] ?? null;

if (!$id || !ctype_digit((string)$id)) {
    die("Invalid ticket ID.");
}

$stmt = $pdo->prepare(
    "SELECT id, description, emergency_level, submitted_date, status
     FROM tickets
     WHERE id = :id"
);

$stmt->execute(['id' => $id]);
$ticket = $stmt->fetch();

if (!$ticket) {
    die("Ticket not found.");
}



$stmt = $pdo->prepare(
    "SELECT id, name
     FROM users
     WHERE type = :type
     ORDER BY name"
);

$stmt->execute(['type' => 'staff']);
$staffList = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Assign Ticket - Maintenance Request System</title>
   <link rel="stylesheet" href="../ass3/style.css">
</head>
<body>

<?php include 'includes/header.php'; ?>

<main>
    <h2>Assign Ticket #<?php echo htmlspecialchars($ticket['id']); ?></h2>

    <p><strong>Issue Description:</strong> <?php echo htmlspecialchars($ticket['description']); ?></p>
    <p><strong>Urgency Level:</strong> <?php echo htmlspecialchars($ticket['emergency_level']); ?></p>
    <p><strong>Date Submitted:</strong> <?php echo htmlspecialchars($ticket['submitted_date']); ?></p>

    <form action="assign.php" method="post">
        <input type="hidden" name="ticket_id" value="<?php echo htmlspecialchars($ticket['id']); ?>">

        <label for="staff_id">Assign to Staff Member:</label>
        <select id="staff_id" name="staff_id" required>
            <?php foreach ($staffList as $staff): ?>
                <option value="<?php echo $staff['id']; ?>">
                    <?php echo htmlspecialchars($staff['name']); ?>
                </option>
            <?php endforeach; ?>
        </select>

        <button type="submit">Assign Ticket</button>
    </form>
</main>

<?php include 'includes/footer.php'; ?>
</body>
</html>
