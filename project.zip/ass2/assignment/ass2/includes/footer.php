<footer>
    <hr>

    <h3>Elora Maintenance Services</h3>

    <p>Address: Ramallah, Palestine</p>

    <p>Telephone: +970 2 000 0000</p>

    <p>
        Email:
        <a href="mailto:elora2026@Elora.com">
            elora2026@Elora.com
        </a>
    </p>

    <p>
        <a href="../ass1/contact.html">
            Contact Us
        </a>
    </p>

    <p>
        &copy; 2026 Elora Maintenance Services.
        All rights reserved.
    </p>

    <p>
        Amna Saqer - 1230632
    </p>

    <p>
        <a href="http://web1230632.studentprojects.ritaj.ps">
            Amna Saqer Home Page
        </a>
    </p>

</footer>