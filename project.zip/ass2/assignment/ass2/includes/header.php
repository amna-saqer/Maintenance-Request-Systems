<?php
$userType = $_SESSION['user_type'] ?? null;
$userName = $_SESSION['user_name'] ?? null;
?>

<header>

    <h1>
        <img
            src="images/rpa.png"
            alt="Elora Maintenance Services Logo"
            width="40"
            style="vertical-align: middle; margin-right: 10px;"
        >
        Elora Maintenance Services
    </h1>

    <p>
        Reliable Maintenance Solutions for Homes and Businesses
    </p>

    <nav>

        <a href="ticketsys.php">Home</a> |

        <a href="../ass1/contact.html">Contact Us</a> |

        <?php if ($userType === 'manager'): ?>

            <a href="ticketsys.php">View Tickets</a> |

        <?php elseif ($userType === 'customer'): ?>

            <a href="ticketsys.php">View My Tickets</a> |

            <a href="request.php">Submit Maintenance Request</a> |

        <?php endif; ?>

        <?php if ($userType): ?>

            <a href="logout.php">Logout</a>

        <?php else: ?>

            <a href="login.php">Login</a>

        <?php endif; ?>

    </nav>

    <?php if ($userName): ?>

        <p>
            Welcome,
            <?= htmlspecialchars($userName) ?>
        </p>

    <?php endif; ?>

</header>