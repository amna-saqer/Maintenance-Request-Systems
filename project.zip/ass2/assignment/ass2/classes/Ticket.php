<?php

class Ticket {

    public $id;
    public $customer_name;
    public $customer_email;
    public $description;
    public $submitted_date;
    public $status;
    public $emergency_level;
    public $assigned_date;
    public $assigned_staff;
    public $image_name;
    public $location;

    public function __construct($row)
    {
        $this->id              = $row['id'];
        $this->customer_name   = $row['customer_name'];
        $this->customer_email  = $row['customer_email'];
        $this->description     = $row['description'];
        $this->submitted_date  = $row['submitted_date'];
        $this->status          = $row['status'];
        $this->emergency_level = $row['emergency_level'];
        $this->assigned_date   = $row['assigned_date'];
        $this->assigned_staff  = $row['staff_name'] ?? "Not assigned";
        $this->image_name      = $row['image_name'];
        $this->location        = $row['location'];
    }

  public function displayTable($isManager){
    $row = "<tr>";
  
    $row .= "<td>";
    $row .= "<a href='view.php?id=" . urlencode($this->id) . "'>";
    $row .= htmlspecialchars($this->id);
    $row .= "</a>";
    $row .= "</td>";

    $row .= "<td>";
    $row .= htmlspecialchars($this->customer_name);
    $row .= "</td>";

  
    $row .= "<td>";
    $row .= htmlspecialchars($this->description);
    $row .= "</td>";

    $row .= "<td>";
    $row .= htmlspecialchars($this->submitted_date);
    $row .= "</td>";

    $row .= "<td>";
    $row .= htmlspecialchars($this->emergency_level);
    $row .= "</td>";

    $row .= "<td>";
    $row .= htmlspecialchars($this->status);
    $row .= "</td>";

   
    $row .= "<td>";

    if ($isManager) {

        $row .= "<a href='assign.php?id=" . urlencode($this->id) . "'>";
        $row .= "<img src='images/icons/assign.png' ";
        $row .= "alt='Assign' title='Assign' width='30'>";
        $row .= "</a>";

        $row .= "&nbsp;";

        
        $row .= "<a href='view.php?id=" . urlencode($this->id) . "'>";
        $row .= "<img src='images/icons/view.png' ";
        $row .= "alt='View' title='View' width='30'>";
        $row .= "</a>";

    } else {

        $row .= "<a href='view.php?id=" . urlencode($this->id) . "'>";
        $row .= "<img src='images/icons/view.png' ";
        $row .= "alt='View' title='View' width='30'>";
        $row .= "</a>";
    }

    $row .= "</td>";

    $row .= "</tr>";

    return $row;
}

    public function displayTicketPage()
    {
        return "
        <main>
            <section class='ticket-view'>
                <h2>Ticket #{$this->id}</h2>

                <p><strong>Customer:</strong> {$this->customer_name}</p>
                <p><strong>Email:</strong> {$this->customer_email}</p>
                <p><strong>Location:</strong> {$this->location}</p>
                <p><strong>Description:</strong> {$this->description}</p>
                <p><strong>Submitted Date:</strong> {$this->submitted_date}</p>
                <p><strong>Status:</strong> {$this->status}</p>
                <p><strong>Emergency Level:</strong> {$this->emergency_level}</p>
                <p><strong>Assigned Staff:</strong> {$this->assigned_staff}</p>
                <p><strong>Assigned Date:</strong> {$this->assigned_date}</p>

                <a href='ticketsys.php' class='btn'>Back to Dashboard</a>
            </section>
        </main>
        ";
    }
}
