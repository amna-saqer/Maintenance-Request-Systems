DROP TABLE IF EXISTS tickets;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    type ENUM('manager', 'customer', 'staff') NOT NULL
);

CREATE TABLE tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    email VARCHAR(150) NOT NULL,
    location VARCHAR(150) NOT NULL,
    description TEXT NOT NULL,
    emergency_level ENUM('Low', 'Medium', 'High') NOT NULL,
    submitted_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status ENUM('Pending', 'In Progress', 'Resolved') NOT NULL DEFAULT 'Pending',
    assigned_date DATETIME NULL,
    assigned_staff_id INT NULL,
    assigned_staff VARCHAR(100) NULL,
    image_name VARCHAR(255) NULL,
    FOREIGN KEY (customer_id) REFERENCES users(id)
);

INSERT INTO users (name, email, password, type) VALUES
('Main Manager', 'manger@gmail.com', '$2y$12$9kPR4RnKQLvaoaUP0Ft9ruppcQZPqMAWXlaYNpB.JAL92TiSn/8/C', 'manager'),
('Manager Two', 'manager2@gmail.com', '$2y$12$9kPR4RnKQLvaoaUP0Ft9ruppcQZPqMAWXlaYNpB.JAL92TiSn/8/C', 'manager'),
('Manager Three', 'manager3@gmail.com', '$2y$12$9kPR4RnKQLvaoaUP0Ft9ruppcQZPqMAWXlaYNpB.JAL92TiSn/8/C', 'manager');


INSERT INTO users (name, email, password, type) VALUES
('Main Customer', 'cust@gmail.com', '$2y$12$AVDGi9vbSBiImyZnMjVG6uP0eOHiao9RbFOfMOHfGJP5x7pHzpsTy', 'customer'),
('Customer Two', 'customer2@gmail.com', '$2y$12$9kPR4RnKQLvaoaUP0Ft9ruppcQZPqMAWXlaYNpB.JAL92TiSn/8/C', 'customer'),
('Customer Three', 'customer3@gmail.com', '$2y$12$9kPR4RnKQLvaoaUP0Ft9ruppcQZPqMAWXlaYNpB.JAL92TiSn/8/C', 'customer'),
('Customer Four', 'customer4@gmail.com', '$2y$12$9kPR4RnKQLvaoaUP0Ft9ruppcQZPqMAWXlaYNpB.JAL92TiSn/8/C', 'customer'),
('Customer Five', 'customer5@gmail.com', '$2y$12$9kPR4RnKQLvaoaUP0Ft9ruppcQZPqMAWXlaYNpB.JAL92TiSn/8/C', 'customer'),
('Customer Six', 'customer6@gmail.com', '$2y$12$9kPR4RnKQLvaoaUP0Ft9ruppcQZPqMAWXlaYNpB.JAL92TiSn/8/C', 'customer'),
('Customer Seven', 'customer7@gmail.com', '$2y$12$9kPR4RnKQLvaoaUP0Ft9ruppcQZPqMAWXlaYNpB.JAL92TiSn/8/C', 'customer'),
('Customer Eight', 'customer8@gmail.com', '$2y$12$9kPR4RnKQLvaoaUP0Ft9ruppcQZPqMAWXlaYNpB.JAL92TiSn/8/C', 'customer'),
('Customer Nine', 'customer9@gmail.com', '$2y$12$9kPR4RnKQLvaoaUP0Ft9ruppcQZPqMAWXlaYNpB.JAL92TiSn/8/C', 'customer'),
('Customer Ten', 'customer10@gmail.com', '$2y$12$9kPR4RnKQLvaoaUP0Ft9ruppcQZPqMAWXlaYNpB.JAL92TiSn/8/C', 'customer');

INSERT INTO users (name, email, password, type) VALUES
('Staff One', 'staff1@example.com', '$2y$12$9kPR4RnKQLvaoaUP0Ft9ruppcQZPqMAWXlaYNpB.JAL92TiSn/8/C', 'staff'),
('Staff Two', 'staff2@example.com', '$2y$12$9kPR4RnKQLvaoaUP0Ft9ruppcQZPqMAWXlaYNpB.JAL92TiSn/8/C', 'staff'),
('Staff Three', 'staff3@example.com', '$2y$12$9kPR4RnKQLvaoaUP0Ft9ruppcQZPqMAWXlaYNpB.JAL92TiSn/8/C', 'staff'),
('Staff Four', 'staff4@example.com', '$2y$12$9kPR4RnKQLvaoaUP0Ft9ruppcQZPqMAWXlaYNpB.JAL92TiSn/8/C', 'staff'),
('Staff Five', 'staff5@example.com', '$2y$12$9kPR4RnKQLvaoaUP0Ft9ruppcQZPqMAWXlaYNpB.JAL92TiSn/8/C', 'staff'),
('Staff Six', 'staff6@example.com', '$2y$12$9kPR4RnKQLvaoaUP0Ft9ruppcQZPqMAWXlaYNpB.JAL92TiSn/8/C', 'staff'),
('Staff Seven', 'staff7@example.com', '$2y$12$9kPR4RnKQLvaoaUP0Ft9ruppcQZPqMAWXlaYNpB.JAL92TiSn/8/C', 'staff'),
('Staff Eight', 'staff8@example.com', '$2y$12$9kPR4RnKQLvaoaUP0Ft9ruppcQZPqMAWXlaYNpB.JAL92TiSn/8/C', 'staff'),
('Staff Nine', 'staff9@example.com', '$2y$12$9kPR4RnKQLvaoaUP0Ft9ruppcQZPqMAWXlaYNpB.JAL92TiSn/8/C', 'staff'),
('Staff Ten', 'staff10@example.com', '$2y$12$9kPR4RnKQLvaoaUP0Ft9ruppcQZPqMAWXlaYNpB.JAL92TiSn/8/C', 'staff');


INSERT INTO tickets
(customer_id, email, location, description, emergency_level, status, assigned_staff)
VALUES
(4, 'cust@gmail.com', 'Room 101', 'Air conditioner is not working.', 'High', 'Pending', NULL),
(5, 'customer2@gmail.com', 'Room 202', 'The light is broken.', 'Low', 'Pending', NULL),
(6, 'customer3@gmail.com', 'Lab 3', 'Computer power problem.', 'Medium', 'Pending', NULL),
(7, 'customer4@gmail.com', 'Office 5', 'Water leakage near the window.', 'High', 'Pending', NULL),
(8, 'customer5@gmail.com', 'Room 305', 'Door lock needs repair.', 'Medium', 'Pending', NULL),
(9, 'customer6@gmail.com', 'Lab 1', 'Network socket is damaged.', 'Low', 'Pending', NULL),
(10, 'customer7@gmail.com', 'Hall 2', 'Ceiling lamp is flickering.', 'Medium', 'Pending', NULL),
(11, 'customer8@gmail.com', 'Office 2', 'Printer is not working.', 'Low', 'Pending', NULL),
(12, 'customer9@gmail.com', 'Room 110', 'Heating system issue.', 'High', 'Pending', NULL),
(13, 'customer10@gmail.com', 'Lab 4', 'Broken desk needs maintenance.', 'Low', 'Pending', NULL);
