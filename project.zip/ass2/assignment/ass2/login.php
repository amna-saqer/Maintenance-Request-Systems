<?php
session_start();

require 'dbconfig.in.php';
require 'makehash.php';



$error = '';


if (isset($_SESSION['user_id'])) {
    header('Location: ticketsys.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $error = 'Please enter both email and password.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email");
        $stmt->execute(['email' => $email]);
        $user = $stmt->fetch();

      if ($user && HashMaker::verify($password, $user['password'])) {
            $_SESSION['user_id']   = $user['id'];
            $_SESSION['user_name'] = $user['name'];
           $_SESSION['user_type'] = $user['type'];
            header('Location: ticketsys.php');
            exit;
        } else {
            $error = 'Invalid email or password. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Maintenance Request System</title>
    <link rel="stylesheet" href="../ass3/style.css">
  
</head>
<body>
<?php include 'includes/header.php'; ?>
<main class="login-box">
    <h2>Login</h2>

    <?php if ($error): ?>
        <p class="error"><?php echo htmlspecialchars($error); ?></p>
    <?php endif; ?>

    <form action="login.php" method="post">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" placeholder="Enter your email" required>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" placeholder="Enter your password" required>

        <button type="submit">Login</button>
    </form>
</main>

<?php include 'includes/footer.php'; ?>
</body>

</html>
