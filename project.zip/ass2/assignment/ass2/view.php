<?php
session_start();

require 'dbconfig.in.php';
require 'classes/Ticket.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$id = $_GET['id'] ?? '';

if ($id === '' || !ctype_digit((string)$id)) {
    echo "Invalid ticket ID.";
    echo "<br><a href='ticketsys.php'>Back to dashboard</a>";
    exit;
}

$sql = "SELECT 
            t.id,
            t.customer_id,
            t.email,
            t.location,
            t.description,
            t.submitted_date,
            t.status,
            t.emergency_level,
            t.assigned_date,
            t.assigned_staff_id,
            t.image_name,
            c.name AS customer_name,
            c.email AS customer_email,
            s.name AS staff_name
        FROM tickets t
        JOIN users c ON t.customer_id = c.id
        LEFT JOIN users s ON t.assigned_staff_id = s.id
        WHERE t.id = :id";

$stmt = $pdo->prepare($sql);
$stmt->execute(['id' => $id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row) {
    echo "Invalid ticket ID.";
    echo "<br><a href='ticketsys.php'>Back to dashboard</a>";
    exit;
}

$ticket = new Ticket($row);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Ticket</title>
 <link rel="stylesheet" href="../ass3/style.css">
</head>

<body>

<?php include 'includes/header.php'; ?>

<?php
echo $ticket->displayTicketPage();
?>

<?php include 'includes/footer.php'; ?>

</body>
</html>