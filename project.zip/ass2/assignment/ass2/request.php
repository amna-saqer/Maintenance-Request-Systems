<?php

session_start();
require 'dbconfig.in.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'customer') {
    header('Location: login.php');
    exit;
}

$userId   = $_SESSION['user_id'];
$userName = $_SESSION['user_name'];
$error    = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email       = trim($_POST['email'] ?? '');
    $location    = trim($_POST['location'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $urgency     = $_POST['urgency'] ?? 'Low';

    if ($email === '' || $location === '' || $description === '') {

        $error = 'Please fill in all required fields.';

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $error = 'Please enter a valid email address.';

    } elseif (!in_array($urgency, ['Low', 'Medium', 'High'], true)) {

        $error = 'Invalid urgency level.';

    } elseif (
        !isset($_FILES['photo']) ||
        $_FILES['photo']['error'] !== UPLOAD_ERR_OK
    ) {

        $error = 'Please upload a JPEG image.';

    } else {

        $file = $_FILES['photo'];

     $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

if ($extension !== 'jpeg') {

            $error = 'Only JPEG images are accepted.';

        } else {

            try {

                $pdo->beginTransaction();

            
                $stmt = $pdo->prepare(
                    "INSERT INTO tickets
                    (
                        customer_id,
                        email,
                        location,
                        description,
                        emergency_level,
                        submitted_date,
                        status,
                        image_name
                    )
                    VALUES
                    (
                        :customer_id,
                        :email,
                        :location,
                        :description,
                        :emergency_level,
                        NOW(),
                        'Pending',
                        NULL
                    )"
                );

                $stmt->execute([
                    ':customer_id'    => $userId,
                    ':email'          => $email,
                    ':location'       => $location,
                    ':description'    => $description,
                    ':emergency_level'=> $urgency
                ]);

              
                $ticketId = (int)$pdo->lastInsertId();

                $imageDir = __DIR__ . '/images';

                if (!is_dir($imageDir)) {
                    mkdir($imageDir, 0755, true);
                }

                $imageName = $ticketId . '.jpeg';
                $destination = $imageDir . '/' . $imageName;

                if (!move_uploaded_file($file['tmp_name'], $destination)) {
                    throw new Exception('Could not save uploaded image.');
                }

                $update = $pdo->prepare(
                    "UPDATE tickets
                     SET image_name = :image_name
                     WHERE id = :id"
                );

                $update->execute([
                    ':image_name' => $imageName,
                    ':id'         => $ticketId
                ]);

                $pdo->commit();

                header("Location: confirm.php?id=" . $ticketId);
                exit;

            } catch (Exception $e) {

                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }

                $error = 'Could not submit the maintenance request.';
            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <title>Submit Maintenance Request</title>
     <link rel="stylesheet" href="../ass3/style.css">

</head>

<body>

<?php include 'includes/header.php'; ?>

<main>

    <section class="card">

        <h2>Submit a Maintenance Request</h2>

        <?php if ($error): ?>

            <p class="error">
                <?php echo htmlspecialchars($error); ?>
            </p>

        <?php endif; ?>


        <form
            action="request.php"
            method="post"
            enctype="multipart/form-data"
        >

            <label for="name">
                Full Name:
            </label>

            <input
                type="text"
                id="name"
                value="<?php echo htmlspecialchars($userName); ?>"
                disabled
            >

            <label for="email">
                Email Address:
            </label>

            <input
                type="email"
                id="email"
                name="email"
                placeholder="Enter your email"
                required
            >

            <label for="location">
                Location / Room Number:
            </label>

            <input
                type="text"
                id="location"
                name="location"
                placeholder="Enter the room or location"
                required
            >

            <label for="description">
                Issue Description:
            </label>

            <textarea
                id="description"
                name="description"
                rows="5"
                placeholder="Describe the issue..."
                required
            ></textarea>

            <label for="urgency">
                Urgency Level:
            </label>

            <select
                id="urgency"
                name="urgency"
                required
            >

                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>

            </select>

            <label for="photo">
                Upload a JPEG Photo:
            </label>

            <input
                type="file"
                id="photo"
                name="photo"
                accept=".jpeg,image/jpeg"
                required
            >

            <br><br>

            <button type="submit">
                Submit Request
            </button>

        </form>

    </section>

</main>

<?php include 'includes/footer.php'; ?>

</body>

</html>