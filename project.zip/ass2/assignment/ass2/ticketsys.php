<?php

session_start();

require 'dbconfig.in.php';
require 'classes/Ticket.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$userType = $_SESSION['user_type'];
$userId   = $_SESSION['user_id'];


$sql = "
    SELECT
        t.id,
        t.description,
        t.submitted_date,
        t.status,
        t.emergency_level,
        t.assigned_date,
        t.image_name,
        t.location,

        c.name AS customer_name,
        c.email AS customer_email,

        s.name AS staff_name

    FROM tickets t

    JOIN users c
        ON t.customer_id = c.id

    LEFT JOIN users s
        ON t.assigned_staff_id = s.id

    WHERE 1 = 1
";

$params = [];

if ($userType === 'customer') {

    $sql .= " AND t.customer_id = :customer_id";

    $params[':customer_id'] = $userId;
}

$description    = trim($_POST['description'] ?? '');
$customerName   = trim($_POST['customer_name'] ?? '');
$submissionDate = trim($_POST['submission_date'] ?? '');

$status = $_POST['status'] ?? 'All';

$emergency = $_POST['emergency'] ?? 'All';

$isPost = $_SERVER['REQUEST_METHOD'] === 'POST';

if ($description !== '') {

    $sql .= " AND t.description LIKE :description";

    $params[':description'] = '%' . $description . '%';
}

if ($userType === 'manager' && $customerName !== '') {

    $sql .= " AND c.name LIKE :customer_name";

    $params[':customer_name'] = '%' . $customerName . '%';
}


if ($submissionDate !== '') {

    $sql .= " AND DATE(t.submitted_date) = :submission_date";

    $params[':submission_date'] = $submissionDate;
}


if ($status !== 'All' && $status !== '') {

    $sql .= " AND t.status = :status";

    $params[':status'] = $status;

} elseif (!$isPost) {

    $sql .= " AND t.status = :default_status";

    $params[':default_status'] = 'Pending';
}

if ($emergency !== 'All' && $emergency !== '') {

    $sql .= " AND t.emergency_level = :emergency";

    $params[':emergency'] = $emergency;
}


$sql .= " ORDER BY t.submitted_date DESC";


$stmt = $pdo->prepare($sql);

$stmt->execute($params);

$tickets = [];

foreach ($stmt->fetchAll() as $row) {

    $tickets[] = new Ticket($row);
}

$statusOptions = [
    'All',
    'Pending',
    'In Progress',
    'Resolved'
];

$emergencyOptions = [
    'All',
    'Low',
    'Medium',
    'High'
];

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <title>
        <?php
        echo $userType === 'manager'
            ? 'Manager Dashboard'
            : 'Customer Dashboard';
        ?>
    </title>

   <link rel="stylesheet" href="../ass3/style.css">

</head>


<body>


<?php include 'includes/header.php'; ?>


<main>


    <section class="search-panel">

        <h2>

            <?php

            echo $userType === 'manager'
                ? 'Manager Dashboard'
                : 'My Tickets';

            ?>

        </h2>


        <form
            action="ticketsys.php"
            method="post"
        >


            <label for="description">
                Ticket Description:
            </label>

            <input
                type="text"
                id="description"
                name="description"
                placeholder="Search by description..."
                value="<?php echo htmlspecialchars($description); ?>"
            >


            <?php if ($userType === 'manager'): ?>

                <label for="customer_name">
                    Customer Name:
                </label>

                <input
                    type="text"
                    id="customer_name"
                    name="customer_name"
                    placeholder="Search by customer name..."
                    value="<?php echo htmlspecialchars($customerName); ?>"
                >

            <?php endif; ?>


            <label for="submission_date">
                Submission Date:
            </label>

            <input
                type="date"
                id="submission_date"
                name="submission_date"
                value="<?php echo htmlspecialchars($submissionDate); ?>"
            >


            <label for="status">
                Status:
            </label>

            <select
                id="status"
                name="status"
            >

                <?php foreach ($statusOptions as $option): ?>

                    <option
                        value="<?php echo htmlspecialchars($option); ?>"
                        <?php
                        echo $status === $option
                            ? 'selected'
                            : '';
                        ?>
                    >

                        <?php echo htmlspecialchars($option); ?>

                    </option>

                <?php endforeach; ?>

            </select>


            <label for="emergency">
                Emergency Level:
            </label>

            <select
                id="emergency"
                name="emergency"
            >

                <?php foreach ($emergencyOptions as $option): ?>

                    <option
                        value="<?php echo htmlspecialchars($option); ?>"
                        <?php
                        echo $emergency === $option
                            ? 'selected'
                            : '';
                        ?>
                    >

                        <?php echo htmlspecialchars($option); ?>

                    </option>

                <?php endforeach; ?>

            </select>


            <button type="submit">
                Filter
            </button>


        </form>

    </section>


    <?php if ($userType === 'customer'): ?>

        <p>

            <a
                class="button"
                href="request.php"
            >
                Submit Maintenance Request
            </a>

        </p>

    <?php endif; ?>


    <section class="ticket-list">

        <h2>Ticket List</h2>


        <table>

            <thead>

                <tr>

                    <th>Ticket ID</th>

                    <th>Customer Name</th>

                    <th>Description</th>

                    <th>Submitted Date</th>

                    <th>Emergency Level</th>

                    <th>Status</th>

                    <th>Actions</th>

                </tr>

            </thead>


            <tbody>


            <?php if (!$tickets): ?>

                <tr>

                    <td colspan="7">
                        No tickets found.
                    </td>

                </tr>

            <?php else: ?>


                <?php foreach ($tickets as $ticket): ?>

                    <?php
                    echo $ticket->displayTable(
                        $userType === 'manager'
                    );
                    ?>

                <?php endforeach; ?>


            <?php endif; ?>


            </tbody>

        </table>

    </section>


</main>


<?php include 'includes/footer.php'; ?>


</body>

</html>