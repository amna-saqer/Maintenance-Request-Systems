<?php

session_start();

require 'dbconfig.in.php';

if (
    !isset($_SESSION['user_id']) ||
    $_SESSION['user_type'] !== 'customer'
) {
    header('Location: login.php');
    exit;
}

$id = $_GET['id'] ?? null;

if (!$id || !ctype_digit((string)$id)) {
    die("Invalid ticket reference.");
}


$stmt = $pdo->prepare(
    "SELECT
        t.*,
        c.name AS customer_name,
        c.email AS customer_email
     FROM tickets t
     JOIN users c
        ON t.customer_id = c.id
     WHERE t.id = :id
       AND t.customer_id = :cust_id"
);

$stmt->execute([
    'id' => $id,
    'cust_id' => $_SESSION['user_id']
]);

$ticket = $stmt->fetch();

if (!$ticket) {
    die("We couldn't find that request.");
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../ass3/style.css">

    <title>Request Confirmation</title>


</head>

<body>

<?php include 'includes/header.php'; ?>


<main>

    <section class="card">

        <h2>
            Request Submitted Successfully
        </h2>


        <p class="success">

            Dear
            <?= htmlspecialchars($ticket['customer_name']) ?>,

            thank you for submitting your maintenance request.

        </p>


        <p>

            Your ticket has been created in the system with
            reference number:

            <strong>
                <?= htmlspecialchars($ticket['id']) ?>
            </strong>

        </p>


        <h3>
            Request Summary
        </h3>


        <ul>

            <li>
                <strong>Full Name:</strong>
                <?= htmlspecialchars($ticket['customer_name']) ?>
            </li>


            <li>
                <strong>Email:</strong>
                <?= htmlspecialchars($ticket['customer_email']) ?>
            </li>


            <li>
                <strong>Location:</strong>
                <?= htmlspecialchars($ticket['location']) ?>
            </li>


            <li>
                <strong>Issue Description:</strong>
                <?= htmlspecialchars($ticket['description']) ?>
            </li>


            <li>
                <strong>Urgency Level:</strong>
                <?= htmlspecialchars($ticket['emergency_level']) ?>
            </li>


            <li>
                <strong>Submitted Date:</strong>
                <?= htmlspecialchars($ticket['submitted_date']) ?>
            </li>


            <li>
                <strong>Ticket Status:</strong>
                <?= htmlspecialchars($ticket['status']) ?>
            </li>


            <li>
                <strong>Photo Uploaded:</strong>

                <?= !empty($ticket['image_name']) ? 'Yes' : 'No' ?>

            </li>

        </ul>


        <?php if (!empty($ticket['image_name'])): ?>

            <figure>

                <img
                    src="images/<?= htmlspecialchars($ticket['image_name']) ?>"
                    alt="Uploaded maintenance photo"
                    width="300"
                >

            </figure>

        <?php endif; ?>


        <p>
            Our maintenance team will respond to your request shortly.
        </p>


        <p>

            <a
                class="button"
                href="view.php?id=<?= urlencode($ticket['id']) ?>"
            >
                View Ticket
            </a>


            <a
                class="button"
                href="ticketsys.php"
            >
                Back to Dashboard
            </a>

        </p>

    </section>

</main>


<?php include 'includes/footer.php'; ?>


</body>

</html>